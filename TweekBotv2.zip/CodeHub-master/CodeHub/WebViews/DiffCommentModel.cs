﻿namespace CodeHub.WebViews
{
    public class DiffCommentModel
    {
        public int Id;
        public int? GroupId;
        public string Username;
        public string AvatarUrl;
        public int? LineTo;
        public int? LineFrom;
        public string Body;
        public string Date;
    }
}
