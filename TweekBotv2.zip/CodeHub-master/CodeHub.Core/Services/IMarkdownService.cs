using System;

namespace CodeHub.Core.Services
{
    public interface IMarkdownService
    {
        string Convert(string s);
    }
}

