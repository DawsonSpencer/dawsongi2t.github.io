namespace CodeHub.Core.Services
{
    public interface IViewModelTxService
    {
        void Add(object obj);

        object Get();
    }
}

