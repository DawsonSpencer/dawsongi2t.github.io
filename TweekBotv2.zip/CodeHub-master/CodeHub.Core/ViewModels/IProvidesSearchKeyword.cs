﻿namespace CodeHub.Core.ViewModels
{
    public interface IProvidesSearchKeyword
    {
        string SearchKeyword { get; set; }
    }
}
