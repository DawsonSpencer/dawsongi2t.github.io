﻿namespace CodeHub.Core.Messages
{
    public class LogoutMessage
    {
    }
}

