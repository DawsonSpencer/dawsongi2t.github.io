﻿namespace CodeHub.iOS.Utilities
{
    public enum ShaType
    {
        Branch,
        Tag,
        Hash
    }
}
