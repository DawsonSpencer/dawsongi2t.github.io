// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//

using Foundation;

namespace CodeHub.iOS.TableViewCells
{
    [Register ("IssueCellView")]
    partial class IssueCellView
    {
        [Outlet]
        UIKit.UILabel Caption { get; set; }

        [Outlet]
        UIKit.UILabel Label1 { get; set; }

        [Outlet]
        UIKit.UIImageView Image1 { get; set; }

        [Outlet]
        UIKit.UIImageView Image2 { get; set; }

        [Outlet]
        UIKit.UILabel Label2 { get; set; }

        [Outlet]
        UIKit.UIImageView Image3 { get; set; }

        [Outlet]
        UIKit.UILabel Label3 { get; set; }

        [Outlet]
        UIKit.UIImageView Image4 { get; set; }

        [Outlet]
        UIKit.UILabel Label4 { get; set; }

        [Outlet]
        UIKit.UILabel Number { get; set; }

        [Outlet]
        UIKit.UILabel IssueType { get; set; }
        
        void ReleaseDesignerOutlets ()
        {
            if (Caption != null) {
                Caption.Dispose ();
                Caption = null;
            }

            if (Label1 != null) {
                Label1.Dispose ();
                Label1 = null;
            }

            if (Image1 != null) {
                Image1.Dispose ();
                Image1 = null;
            }

            if (Image2 != null) {
                Image2.Dispose ();
                Image2 = null;
            }

            if (Label2 != null) {
                Label2.Dispose ();
                Label2 = null;
            }

            if (Image3 != null) {
                Image3.Dispose ();
                Image3 = null;
            }

            if (Label3 != null) {
                Label3.Dispose ();
                Label3 = null;
            }

            if (Image4 != null) {
                Image4.Dispose ();
                Image4 = null;
            }

            if (Label4 != null) {
                Label4.Dispose ();
                Label4 = null;
            }

            if (Number != null) {
                Number.Dispose ();
                Number = null;
            }

            if (IssueType != null) {
                IssueType.Dispose ();
                IssueType = null;
            }
        }
    }
}
