using CodeHub.iOS.Views.Source;

namespace CodeHub.iOS.Views.PullRequests
{
    public class PullRequestCommitsView : CommitsView
    {
    }
}

