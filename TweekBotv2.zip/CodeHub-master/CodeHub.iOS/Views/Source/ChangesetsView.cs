namespace CodeHub.iOS.Views.Source
{
    public class ChangesetsView : CommitsView
    {
    }
}

