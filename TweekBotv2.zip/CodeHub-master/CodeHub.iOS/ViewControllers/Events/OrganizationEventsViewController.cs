namespace CodeHub.iOS.ViewControllers.Events
{
    public class OrganizationEventsViewController : BaseEventsViewController
    {
    }
}

