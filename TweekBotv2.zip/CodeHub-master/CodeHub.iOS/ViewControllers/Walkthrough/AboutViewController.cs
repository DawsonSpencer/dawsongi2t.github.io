﻿namespace CodeHub.iOS.ViewControllers.Walkthrough
{
    public partial class AboutViewController : BaseViewController
    {
        public AboutViewController()
            : base("AboutViewController", null)
        {
        }
    }
}

